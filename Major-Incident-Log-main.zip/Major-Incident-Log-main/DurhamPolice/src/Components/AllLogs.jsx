import React from 'react'

const AllLogs = () => {
  return (
    <div>
      All Logs</div>
  )
}

export default AllLogs;
